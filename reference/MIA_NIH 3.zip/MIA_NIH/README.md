---
title: NIH Chest X-ray MIA
emoji: 🩻
colorFrom: purple
colorTo: red
sdk: gradio
sdk_version: "5.29.0"
python_version: "3.11"
app_file: app.py
pinned: false
---

# NIH Chest X-ray Membership Inference Attack

Deliberately-overfitted ResNet-18 victim → shadow-model MIA (baseline + variance-enhanced).

## What this does

1. Downloads ~5,000 frontal chest X-rays from the NIH ChestX-ray14 dataset.
2. Converts the multi-label annotations into a clean 4-class single-label problem (Softmax CNN — avoids the sigmoid-collapse issue that broke the CheXpert run).
3. Trains a ResNet-18 victim on 3,000 of those images with **no regularization** so that train accuracy clearly exceeds val accuracy. That memorization gap is the signal MIA exploits.
4. Runs two attacks:
   - **Baseline Shadow MIA** — Shokri et al. style with confidence vectors as features.
   - **Variance-Enhanced MIA** — adds the variance of the max-confidence across 15 shadow models as an extra feature.
5. Writes `attack_results_nih.txt`.

## Files

| File | Purpose |
|---|---|
| `mia.py` | Core MIA class — **do not modify** |
| `mia_variance.py` | Variance-enhanced subclass — **do not modify** |
| `prepare_nih_dataset.py` | Downloads `images_001.zip` (~4.4 GB) + labels CSV, builds `nih_manifest.csv` |
| `train_nih_victim.py` | Trains the overfitted ResNet-18, writes `nih_victim.pth` + `nih_victim_meta.json` |
| `api_nih.py` | PyTorch model wrapper; same `predict(paths) → softmax_probs` shape as `api_braintumor.py` |
| `run_attack_nih.py` | The actual attack — pre-computes scores, runs both MIA variants, writes `attack_results_nih.txt` |
| `app.py` | Optional Gradio UI for one-click runs on a Space |
| `requirements.txt` | Pinned dependencies |

## Two ways to run on Hugging Face

### Option A — Plain script run on a GPU Space (recommended, simpler)

This is the cheapest and easiest path.

1. Create a new Space:
   - **SDK:** Gradio (or `Docker` if you prefer; Gradio is fine because the app file just provides a UI shell).
   - **Hardware:** **T4 small** (~$0.40/hr) or **T4 medium** (~$0.60/hr). A10G is overkill here.
2. Upload all files in this folder to the Space (or push via `git`).
3. In the Space's **Logs** tab, click **Restart Space** once so the build completes.
4. Open the **Files** → **Settings** → **Variables and secrets** screen and confirm `--persistent-storage` is **off** (we don't need it).
5. From the Space's terminal (Settings → Open in JupyterLab → Terminal), run:
   ```bash
   pip install -r requirements.txt
   python prepare_nih_dataset.py    # ~5–8 min (download + extract)
   python train_nih_victim.py        # ~6–12 min on T4
   python run_attack_nih.py          # ~3–5 min
   ```
6. Download `attack_results_nih.txt` from the Files tab.

**Estimated total cost on T4 small:** ~$0.20–0.40 (well under your $30 budget, and you can re-run several times).

### Option B — One-click Gradio UI

If you'd rather not touch a terminal:

1. Same Space setup as Option A, with `app.py` as the entry point (already configured in this README's frontmatter).
2. After the Space builds, open it in your browser.
3. Click **Run Full Pipeline**. Logs stream into the textbox; the final results file becomes downloadable when the run finishes.

Note: Gradio's request timeout can interrupt very long callbacks. If you hit a UI timeout, just refresh — the underlying scripts will see the model files already exist and skip ahead. Or use Option A.

## Local / Colab fallback

You don't actually need an HF Space — these scripts run anywhere with a recent GPU and Python 3.10+:

```bash
pip install -r requirements.txt
python prepare_nih_dataset.py
python train_nih_victim.py
python run_attack_nih.py
```

Disk needed: ~10 GB (4.4 GB zip + 4.4 GB extracted PNGs + ~50 MB model).

## Expected timings on a T4 (16 GB) GPU

| Step | Wall time |
|---|---|
| Download `images_001.zip` (4.4 GB) | 2–6 min (network bound) |
| Extract 4,999 PNGs | ~1 min |
| Train victim, 12 epochs, batch 32 | 6–10 min |
| Pre-compute victim scores on 3,000 images | ~1 min |
| Both shadow MIA attacks (CPU sklearn) | ~2 min |
| **Total** | **~15–25 min** |

## Troubleshooting

- **`Memorization gap is small`**: training didn't overfit enough. Increase `--epochs` (e.g. `python train_nih_victim.py --epochs 20`) or lower the LR.
- **OOM during training**: lower batch size: `python train_nih_victim.py --batch_size 16`.
- **Download hangs**: the HF mirror is occasionally slow. Re-run; the download resumes from disk.
- **`mia.py` complains about num_classes mismatch**: this happens if `num_classes` in the meta JSON doesn't match what's saved in the .pth. Delete both and retrain.

## Design notes (why these choices)

- **Why `images_001.zip` and not the full dataset?** The full HF dataset is 45 GB across 12 zips. We only need ~5,000 images. The first zip alone gives us 4,999, which is exactly enough.
- **Why exclude "No Finding" from the kept classes?** It dominates ~50% of the dataset and would make the classification trivial — no useful confidence variation, no MIA signal.
- **Why fine-tune all ResNet-18 layers (not just the last)?** The original prompt suggested last-layer-only "for speed," but last-layer-only is itself a regularizer and conflicts with the "we want overfitting" goal. Full fine-tuning on 3,000 images takes the same wall time on a T4 and gives a much cleaner train/val gap, which is what MIA needs.
- **Why softmax + single-label instead of sigmoid + multi-label?** As your CheXpert experiment showed, sigmoid + `argmax` collapses to class 0 and breaks the shadow-model setup. Softmax with single-label labels is the only architecture for which the existing `mia.py` actually works.
