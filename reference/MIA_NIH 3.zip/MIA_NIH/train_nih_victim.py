"""
train_nih_victim.py
===================
Train a DenseNet-121 victim model on the MEMBER-ONLY portion of the NIH
Chest X-ray dataset. This script is adapted from the user's train_densenet.py
but restricts training to members only (to create the MIA signal).

Design choices to encourage overfitting:
  * Full fine-tune (all layers trainable), pretrained from ImageNet.
  * NO dropout, NO weight decay, NO data augmentation.
  * Train for enough epochs that train_acc clearly exceeds val_acc.

Inputs:
  nih_manifest.csv  (produced by prepare_nih_dataset.py)

Outputs:
  nih_victim.pth                    <- model weights
  nih_victim_meta.json              <- num_classes, label names, image size
"""

import os
import sys
import json
import time
import ast
import argparse
import numpy as np
import pandas as pd

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models
from PIL import Image

# -------------------- Configuration --------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MANIFEST_PATH = os.path.join(BASE_DIR, "nih_manifest.csv")
MODEL_PATH = os.path.join(BASE_DIR, "nih_victim.pth")
META_PATH = os.path.join(BASE_DIR, "nih_victim_meta.json")

# Disease classes (must match prepare_nih_dataset.py exactly)
DISEASE_CLASSES = [
    'Atelectasis', 'Consolidation', 'Infiltration', 'Pneumothorax', 'Edema',
    'Emphysema', 'Fibrosis', 'Effusion', 'Pneumonia', 'Pleural_thickening',
    'Cardiomegaly', 'Nodule', 'Mass', 'Hernia', 'No Finding'
]

# Hyperparameters – designed to OVERFIT (for MIA signal)
NUM_EPOCHS = 30
BATCH_SIZE = 64
LEARNING_RATE = 1e-4
IMG_SIZE = 224
VAL_FRACTION = 0.15       # fraction of *members* held out for val
RANDOM_SEED = 42


# -------------------- Dataset --------------------
class NIHChestDataset(Dataset):
    """PyTorch dataset for NIH Chest X-rays with multi-label targets."""

    IMAGENET_MEAN = [0.485, 0.456, 0.406]
    IMAGENET_STD = [0.229, 0.224, 0.225]

    def __init__(self, df, transform=None):
        self.df = df.reset_index(drop=True)
        if transform is not None:
            self.transform = transform
        else:
            self.transform = transforms.Compose([
                transforms.Resize((IMG_SIZE, IMG_SIZE)),
                transforms.ToTensor(),
                transforms.Normalize(self.IMAGENET_MEAN, self.IMAGENET_STD),
            ])

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        img = Image.open(row["path"]).convert("RGB")
        img = self.transform(img)

        # Parse the string representation of the list "[1, 0, 1, 0, ...]"
        label_list = ast.literal_eval(row["label_idx"])
        return img, torch.tensor(label_list, dtype=torch.float32)


# -------------------- Model --------------------
def build_densenet121(num_classes: int) -> nn.Module:
    """DenseNet-121 with the same 2-layer classifier head as train_densenet.py.
    
    Architecture matches the user's train_densenet.py:
        classifier = Linear(1024, 512) -> ReLU -> Dropout(0.3) -> Linear(512, num_classes)
    
    BUT: We intentionally use NO dropout and NO weight decay to encourage
    overfitting, which is what makes the MIA attack work.
    """
    try:
        from torchvision.models import DenseNet121_Weights
        model = models.densenet121(weights=DenseNet121_Weights.IMAGENET1K_V1)
    except Exception:
        model = models.densenet121(pretrained=True)

    num_features = model.classifier.in_features
    # Match the architecture from train_densenet.py but without dropout
    model.classifier = nn.Sequential(
        nn.Linear(num_features, 512),
        nn.ReLU(),
        # NO dropout – we WANT overfitting for MIA
        nn.Linear(512, num_classes)
    )

    for p in model.parameters():
        p.requires_grad = True

    return model


# -------------------- Train / eval loop --------------------
def evaluate(model, loader, device, num_classes) -> tuple[float, float]:
    """Return (avg_loss, accuracy)."""
    model.eval()
    criterion = nn.BCEWithLogitsLoss()
    total_loss, total_correct, total_n = 0.0, 0, 0

    with torch.no_grad():
        for images, labels in loader:
            images = images.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)
            logits = model(images)
            loss = criterion(logits, labels)
            total_loss += loss.item() * images.size(0)

            preds = (torch.sigmoid(logits) > 0.5).float()
            total_correct += (preds == labels).sum().item()
            total_n += images.size(0) * num_classes

    return total_loss / (total_n / num_classes), total_correct / total_n


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--epochs", type=int, default=NUM_EPOCHS)
    parser.add_argument("--batch_size", type=int, default=BATCH_SIZE)
    parser.add_argument("--lr", type=float, default=LEARNING_RATE)
    args = parser.parse_args()

    # Determinism
    torch.manual_seed(RANDOM_SEED)
    np.random.seed(RANDOM_SEED)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[INFO] Using device: {device}")
    if device.type == "cuda":
        print(f"[INFO] GPU: {torch.cuda.get_device_name(0)}")

    # 1) Load manifest, restrict to members only
    if not os.path.exists(MANIFEST_PATH):
        raise FileNotFoundError(
            f"{MANIFEST_PATH} not found. Run prepare_nih_dataset.py first."
        )
    manifest = pd.read_csv(MANIFEST_PATH)
    member_df = manifest[manifest["split"] == "member"].reset_index(drop=True)

    # Determine num_classes from the label_idx column
    sample_label = ast.literal_eval(member_df["label_idx"].iloc[0])
    num_classes = len(sample_label)
    label_names = DISEASE_CLASSES[:num_classes]

    print(f"[INFO] Member images: {len(member_df)}")
    print(f"[INFO] Num classes:   {num_classes}")
    print(f"[INFO] Class names:   {label_names}")

    # 2) Train/val split (within members) for monitoring overfit gap
    n_val = int(len(member_df) * VAL_FRACTION)
    shuffled = member_df.sample(frac=1.0, random_state=RANDOM_SEED).reset_index(drop=True)
    val_df = shuffled.iloc[:n_val].reset_index(drop=True)
    train_df = shuffled.iloc[n_val:].reset_index(drop=True)
    print(f"[INFO] Training on {len(train_df)} images, "
          f"validating on {len(val_df)} held-out members.")

    train_ds = NIHChestDataset(train_df)
    val_ds = NIHChestDataset(val_df)

    pin = device.type == "cuda"
    train_loader = DataLoader(
        train_ds, batch_size=args.batch_size, shuffle=True,
        num_workers=2, pin_memory=pin,
    )
    val_loader = DataLoader(
        val_ds, batch_size=args.batch_size, shuffle=False,
        num_workers=2, pin_memory=pin,
    )

    # 3) Model + optimizer
    model = build_densenet121(num_classes).to(device)
    # NO weight decay -> we want to memorize
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=0.0)
    criterion = nn.BCEWithLogitsLoss()

    # 4) Train loop
    print("\n[TRAIN] Starting training ...")
    history = {"train_loss": [], "train_acc": [], "val_loss": [], "val_acc": []}

    for epoch in range(1, args.epochs + 1):
        model.train()
        t0 = time.time()
        total_loss, total_correct, total_n = 0.0, 0, 0

        for batch_idx, (images, labels) in enumerate(train_loader):
            images = images.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)

            optimizer.zero_grad()
            logits = model(images)
            loss = criterion(logits, labels)
            loss.backward()
            optimizer.step()

            total_loss += loss.item() * images.size(0)
            preds = (torch.sigmoid(logits) > 0.5).float()
            total_correct += (preds == labels).sum().item()
            total_n += images.size(0) * num_classes

        train_loss = total_loss / (total_n / num_classes)
        train_acc = total_correct / total_n
        val_loss, val_acc = evaluate(model, val_loader, device, num_classes)
        gap_pct = (train_acc - val_acc) * 100
        elapsed = time.time() - t0

        history["train_loss"].append(train_loss)
        history["train_acc"].append(train_acc)
        history["val_loss"].append(val_loss)
        history["val_acc"].append(val_acc)

        print(f"  Epoch {epoch:02d}/{args.epochs}  "
              f"train_loss={train_loss:.4f}  train_acc={train_acc:.4f}  "
              f"val_loss={val_loss:.4f}  val_acc={val_acc:.4f}  "
              f"gap={gap_pct:+.2f}%  ({elapsed:.1f}s)")
        sys.stdout.flush()

    # 5) Save model + metadata
    torch.save(model.state_dict(), MODEL_PATH)
    meta = {
        "architecture": "densenet121",
        "num_classes": num_classes,
        "label_names": label_names,
        "img_size": IMG_SIZE,
        "imagenet_mean": NIHChestDataset.IMAGENET_MEAN,
        "imagenet_std": NIHChestDataset.IMAGENET_STD,
        "final_train_acc": history["train_acc"][-1],
        "final_val_acc": history["val_acc"][-1],
        "memorization_gap": history["train_acc"][-1] - history["val_acc"][-1],
        "epochs": args.epochs,
    }
    with open(META_PATH, "w") as f:
        json.dump(meta, f, indent=2)

    print("\n[DONE]")
    print(f"  Model:      {MODEL_PATH}")
    print(f"  Metadata:   {META_PATH}")
    print(f"  Final train_acc:      {history['train_acc'][-1]:.4f}")
    print(f"  Final val_acc:        {history['val_acc'][-1]:.4f}")
    print(f"  Memorization gap:     {meta['memorization_gap']*100:+.2f}%")

    if meta["memorization_gap"] < 0.10:
        print("\n  WARNING: Memorization gap is small. The MIA may show weak "
              "signal. Consider increasing --epochs.")


if __name__ == "__main__":
    main()
