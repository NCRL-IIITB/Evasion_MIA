"""
api_nih.py
==========
Wrapper for the trained NIH Chest X-ray victim model.

Mirrors the BrainTumorAPI interface (Keras) but uses PyTorch + ResNet-18.
Images are resized to 224x224 and normalized with ImageNet stats.

Usage:
    from api_nih import NIHChestAPI
    api = NIHChestAPI("nih_victim.pth", num_classes=4)
    probs = api.predict(np.array(image_paths, dtype=object))
    # probs.shape == (n_samples, num_classes), softmax probabilities
"""

import json
import os
import numpy as np
import torch
import torch.nn as nn
from torchvision import models, transforms
from PIL import Image


class NIHChestAPI:
    """API wrapping a PyTorch DenseNet-121 victim model.

    Parameters
    ----------
    model_path : str
        Path to the saved state_dict (.pth).
    num_classes : int, optional
        Number of output classes. If None, read from companion metadata file.
    batch_size : int
        Inference batch size.
    device : str, optional
        'cuda' or 'cpu'. Auto-detected when None.
    """

    IMAGENET_MEAN = [0.485, 0.456, 0.406]
    IMAGENET_STD = [0.229, 0.224, 0.225]

    def __init__(
        self,
        model_path: str,
        num_classes: int | None = None,
        batch_size: int = 32,
        device: str | None = None,
        img_size: int = 224,
    ):
        self.model_path = model_path
        self.batch_size = batch_size
        self.img_size = img_size

        # Resolve num_classes from metadata file if not given
        meta_path = model_path.replace(".pth", "_meta.json")
        if os.path.exists(meta_path):
            with open(meta_path, "r") as f:
                meta = json.load(f)
            if num_classes is None:
                num_classes = int(meta["num_classes"])
            self.img_size = int(meta.get("img_size", img_size))

        if num_classes is None:
            raise ValueError(
                "num_classes is required when no metadata file is found."
            )
        self.num_classes = num_classes

        self.device = torch.device(
            device if device is not None
            else ("cuda" if torch.cuda.is_available() else "cpu")
        )

        # Build the architecture (must match what was saved)
        try:
            from torchvision.models import DenseNet121_Weights
            model = models.densenet121(weights=None)  # weights loaded next
        except Exception:
            model = models.densenet121(pretrained=False)

        in_features = model.classifier.in_features
        # Must match the 2-layer head in train_nih_victim.py
        model.classifier = nn.Sequential(
            nn.Linear(in_features, 512),
            nn.ReLU(),
            nn.Linear(512, num_classes)
        )
        state_dict = torch.load(model_path, map_location=self.device)
        model.load_state_dict(state_dict)
        model.eval()
        model.to(self.device)
        self.model = model

        # Preprocessing pipeline (matches training)
        self.transform = transforms.Compose([
            transforms.Resize((self.img_size, self.img_size)),
            transforms.ToTensor(),
            transforms.Normalize(self.IMAGENET_MEAN, self.IMAGENET_STD),
        ])

    def _preprocess(self, file_path: str) -> torch.Tensor:
        """Load and preprocess a single image. Returns (3, H, W) tensor."""
        try:
            img = Image.open(file_path).convert("RGB")
            return self.transform(img)
        except Exception as e:
            print(f"Warning: Failed to load {file_path}: {e}")
            return torch.zeros(3, self.img_size, self.img_size)

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Batched inference returning softmax probabilities.

        Parameters
        ----------
        X : np.ndarray
            Array of image file paths (dtype=object or unicode).

        Returns
        -------
        probs : np.ndarray, shape (n_samples, num_classes)
        """
        n = len(X)
        all_probs = []

        with torch.no_grad():
            for start in range(0, n, self.batch_size):
                end = min(start + self.batch_size, n)
                batch_paths = X[start:end]

                tensors = [self._preprocess(p) for p in batch_paths]
                batch = torch.stack(tensors).to(self.device, non_blocking=True)

                logits = self.model(batch)
                probs = torch.sigmoid(logits).cpu().numpy()
                all_probs.append(probs)

        return np.vstack(all_probs)
