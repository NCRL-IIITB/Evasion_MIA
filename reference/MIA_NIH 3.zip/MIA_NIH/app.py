"""
app.py
======
Gradio interface for running the full MIA pipeline on an HF Space.
Provides three buttons (one per stage) plus log streaming and a download
panel for the final results file.

This is OPTIONAL — you can also just run the scripts directly via the
Space's terminal. See README.md for both workflows.
"""

import os
import sys
import io
import contextlib
import threading
import gradio as gr

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
RESULTS_PATH = os.path.join(BASE_DIR, "attack_results_nih.txt")
MANIFEST_PATH = os.path.join(BASE_DIR, "nih_manifest.csv")
MODEL_PATH = os.path.join(BASE_DIR, "nih_victim.pth")


import subprocess

def read_logs():
    if not os.path.exists("pipeline.log"):
        return "Waiting for process to start..."
    with open("pipeline.log", "r") as f:
        # Read the last 2000 lines to avoid massive payload
        lines = f.readlines()
        return "".join(lines[-2000:])


def step1_prepare():
    if os.path.exists(MANIFEST_PATH):
        return f"Skipped: {MANIFEST_PATH} already exists. Delete it to re-run."
    subprocess.Popen("nohup python prepare_nih_dataset.py > pipeline.log 2>&1 &", shell=True)
    return "Started Dataset Preparation in background. Logs will update shortly..."


def step2_train():
    if os.path.exists(MODEL_PATH):
        return f"Skipped: {MODEL_PATH} already exists. Delete it to re-train."
    subprocess.Popen("nohup python train_nih_victim.py > pipeline.log 2>&1 &", shell=True)
    return "Started Victim Training in background. Logs will update shortly..."


def step3_attack():
    subprocess.Popen("nohup python run_attack_nih.py > pipeline.log 2>&1 &", shell=True)
    return "Started MIA Attack in background. Logs will update shortly..."


def run_all():
    with open("run_all.sh", "w") as f:
        f.write("#!/bin/bash\n")
        f.write("echo '===== STEP 1: Prepare dataset ====='\n")
        f.write("python prepare_nih_dataset.py\n")
        f.write("echo '\n===== STEP 2: Train victim ====='\n")
        f.write("python train_nih_victim.py\n")
        f.write("echo '\n===== STEP 3: Run MIA attacks ====='\n")
        f.write("python run_attack_nih.py\n")
    os.chmod("run_all.sh", 0o755)
    subprocess.Popen("nohup ./run_all.sh > pipeline.log 2>&1 &", shell=True)
    return "Started Full Pipeline in background. Logs will update shortly..."

def check_results():
    if os.path.exists(RESULTS_PATH):
        return RESULTS_PATH
    return None


with gr.Blocks(title="NIH Chest X-ray MIA") as demo:
    gr.Markdown("# NIH Chest X-ray Membership Inference Attack")
    gr.Markdown(
        "Click **Run Full Pipeline** to download the dataset (~10K images), train an "
        "overfitted DenseNet-121 victim (15-class multi-label), and run both MIA variants. "
        "Estimated time on an A10G GPU: **2–3 hours**."
    )

    with gr.Row():
        run_all_btn = gr.Button("Run Full Pipeline", variant="primary", scale=2)
        prep_btn = gr.Button("1. Prepare Dataset")
        train_btn = gr.Button("2. Train Victim")
        attack_btn = gr.Button("3. Run Attacks")

    status_msg = gr.Markdown("Ready.")

    log_box = gr.Textbox(
        label="Logs (Auto-updating)", lines=30, max_lines=200, autoscroll=True,
        show_copy_button=True,
    )
    results_dl = gr.File(label="Download attack_results_nih.txt", interactive=False)

    # Use a Gradio Timer to constantly poll the log file in the background
    timer = gr.Timer(2)
    timer.tick(read_logs, outputs=[log_box])
    timer.tick(check_results, outputs=[results_dl])

    run_all_btn.click(run_all, inputs=[], outputs=[status_msg])
    prep_btn.click(step1_prepare, inputs=[], outputs=[status_msg])
    train_btn.click(step2_train, inputs=[], outputs=[status_msg])
    attack_btn.click(step3_attack, inputs=[], outputs=[status_msg])


if __name__ == "__main__":
    demo.queue().launch(server_name="0.0.0.0", server_port=7860)
