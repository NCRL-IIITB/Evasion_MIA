---
title: Mia Nih
emoji: 🐠
colorFrom: red
colorTo: red
sdk: gradio
sdk_version: 6.13.0
app_file: app.py
pinned: false
short_description: Simulates the mia attack on nia dataset
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
