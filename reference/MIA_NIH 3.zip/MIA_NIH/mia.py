"""
Membership Inference Attack (MIA) Implementation

Based on Shokri et al. "Membership Inference Attacks Against Machine Learning Models"

This module implements the MIA class which orchestrates the full attack pipeline:
  1. Train shadow models to mimic the victim model's behavior
  2. Build an attack dataset from shadow model confidence scores
  3. Train an attack model to distinguish members from non-members
  4. Attack: given new data, predict whether it was in the victim's training set
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import warnings
from shadow_models import PyTorchShadowModel

warnings.filterwarnings("ignore")


# ---------------------------------------------------------------------------
# Placeholder API class – the user will implement this later.
# Assumptions:
#   - api.predict(X) returns confidence scores of shape (n_samples, num_classes)
#     i.e., probability distribution over classes for each input.
# ---------------------------------------------------------------------------
class API:
    """Placeholder for the victim model API.

    The real implementation should expose a single method:
        predict(X: np.ndarray) -> np.ndarray
            X : array of shape (n_samples, n_features)
            Returns: array of shape (n_samples, num_classes) with class
                     probability / confidence scores.
    """

    def predict(self, X: np.ndarray) -> np.ndarray:
        raise NotImplementedError(
            "API.predict() is not implemented yet. "
            "Replace this placeholder with your victim model API."
        )


# ---------------------------------------------------------------------------
# Supported model registry
# ---------------------------------------------------------------------------
_MODEL_REGISTRY = {
    "random_forest": RandomForestClassifier,
    "gradient_boosting": GradientBoostingClassifier,
    "logistic_regression": LogisticRegression,
    "mlp": MLPClassifier,
    "svm": SVC,
    "pytorch_cnn": PyTorchShadowModel,
}


# ---------------------------------------------------------------------------
# ModelParameters – bundles model_type + arbitrary sklearn kwargs
# ---------------------------------------------------------------------------
class ModelParameters:
    """Holds the model type and its hyper-parameters.

    Any keyword argument accepted by the corresponding sklearn estimator
    can be passed here.  Unknown / extra keys are silently forwarded to
    the sklearn constructor so you never need to update this class when
    switching model types.

    Parameters
    ----------
    model_type : str
        One of 'random_forest', 'gradient_boosting', 'logistic_regression',
        'mlp', 'svm'.
    **kwargs
        Arbitrary hyper-parameters forwarded to the sklearn constructor.
        Examples: n_estimators=200, max_depth=10, C=1.0, hidden_layer_sizes=(64, 32).

    Examples
    --------
    >>> shadow_params = ModelParameters("random_forest", n_estimators=200, max_depth=10)
    >>> attack_params = ModelParameters("logistic_regression", C=0.5, max_iter=2000)
    >>> attack_params = ModelParameters("mlp", hidden_layer_sizes=(128, 64), max_iter=500)
    """

    def __init__(self, model_type: str = "random_forest", **kwargs):
        if model_type not in _MODEL_REGISTRY:
            raise ValueError(
                f"Unknown model type '{model_type}'. "
                f"Choose from: {list(_MODEL_REGISTRY.keys())}"
            )
        self.model_type = model_type
        self.params = dict(kwargs)

    def build(self, random_state: int = 42):
        """Construct and return a fresh (unfitted) sklearn estimator."""
        cls = _MODEL_REGISTRY[self.model_type]
        final_params = dict(self.params)  # shallow copy

        # Inject sensible defaults that may be missing
        if self.model_type == "svm" and "probability" not in final_params:
            final_params["probability"] = True  # needed for predict_proba
        if self.model_type == "logistic_regression" and "max_iter" not in final_params:
            final_params["max_iter"] = 1000
        if self.model_type == "mlp" and "max_iter" not in final_params:
            final_params["max_iter"] = 500

        final_params.setdefault("random_state", random_state)
        return cls(**final_params)

    def __repr__(self):
        param_str = ", ".join(f"{k}={v!r}" for k, v in self.params.items())
        return f"ModelParameters('{self.model_type}', {param_str})" if param_str else f"ModelParameters('{self.model_type}')"


class MIA:
    """Membership Inference Attack.

    Trains shadow models to mimic a victim model, then trains an attack model
    to predict whether a given data point was part of the victim model's
    training set based on the confidence scores output by the model.

    Parameters (constructor)
    ------------------------
    victim_model_api : API
        An object whose `.predict(X)` method returns confidence scores
        of shape (n_samples, num_classes).
    unlabelled_data : np.ndarray
        Unlabelled data of shape (n_samples, n_features).
        Assumed to be already preprocessed.
    num_classes : int
        Number of output classes of the victim model.
    num_shadow_models : int, default 5
        Number of shadow models to train.
    shadow_model_dataset_size : int or None
        Size of the training set for each shadow model.
        Defaults to ``len(unlabelled_data) // 2``.
    attack_model_dataset_size : int or None
        Total number of samples (positive + negative, across all shadow
        models) used to build the attack dataset. If None, uses all
        available samples.

    Configurable model parameters (set before calling ``execute()``)
    ----------------------------------------------------------------
    shadow_model_parameters : ModelParameters
        Controls the type and hyper-parameters of every shadow model.
        Default: ``ModelParameters('random_forest')``.
    attack_model_parameters : ModelParameters
        Controls the type and hyper-parameters of the attack model.
        Default: ``ModelParameters('logistic_regression')``.
    random_state : int
        Random seed for reproducibility. Default: 42.

    Examples
    --------
    >>> mia = MIA(api, data, num_classes=10)
    >>> mia.shadow_model_parameters = ModelParameters('mlp', hidden_layer_sizes=(128, 64), max_iter=500)
    >>> mia.attack_model_parameters = ModelParameters('random_forest', n_estimators=200)
    >>> mia.execute()
    >>> predictions = mia.attack(target_data)
    """

    # ------------------------------------------------------------------
    # Construction – store parameters, do NOT train yet
    # ------------------------------------------------------------------
    def __init__(
        self,
        victim_model_api: API,
        unlabelled_data: np.ndarray,
        num_classes: int,
        num_shadow_models: int = 5,
        shadow_model_dataset_size: int | None = None,
        attack_model_dataset_size: int | None = None,
        shadow_model_parameters: ModelParameters | list | None = None,
        attack_model_parameters: ModelParameters | None = None,
    ):
        # --- Core inputs ---
        self.victim_model_api = victim_model_api
        self.unlabelled_data = np.asarray(unlabelled_data)
        self.num_classes = num_classes
        self.num_shadow_models = num_shadow_models
        self.shadow_model_dataset_size = (
            shadow_model_dataset_size
            if shadow_model_dataset_size is not None
            else len(self.unlabelled_data) // 2
        )
        self.attack_model_dataset_size = attack_model_dataset_size

        # --- Model parameters (type + hyper-parameters) ---
        self.shadow_model_parameters = (
            shadow_model_parameters
            if shadow_model_parameters is not None
            else ModelParameters("random_forest")
        )
        self.attack_model_parameters = (
            attack_model_parameters
            if attack_model_parameters is not None
            else ModelParameters("logistic_regression")
        )

        # --- Misc ---
        self.random_state: int = 42

        # --- Internal state (populated after execute()) ---
        self.shadow_models: dict = {}       # idx → {"model": fitted_model, "train_indices": set}
        self.attack_model = None            # fitted attack classifier
        self.attack_dataset: pd.DataFrame | None = None  # the model_dataset from pseudocode
        self._is_trained: bool = False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------
    def execute(self) -> "MIA":
        """Run the full MIA pipeline (Steps 1 → 3).

        Returns self so you can chain: ``mia.execute().attack(data)``.
        """
        print("[MIA] Step 1/3: Training shadow models …")
        self._train_shadow_models()

        print("[MIA] Step 2/3: Preparing attack dataset …")
        self._prepare_attack_dataset()

        print("[MIA] Step 3/3: Training attack model …")
        self._train_attack_model()

        self._is_trained = True
        print("[MIA] Pipeline complete ✓")
        return self

    def attack(self, data: np.ndarray, return_confidence: bool = False):
        """Predict membership of *data* in the victim model's training set.

        Parameters
        ----------
        data : np.ndarray, shape (n_samples, n_features)
            Data points to query.
        return_confidence : bool
            If True, also return the attack model's confidence scores.

        Returns
        -------
        predictions : np.ndarray of {0, 1}, shape (n_samples,)
            1 = predicted member, 0 = predicted non-member.
        confidences : np.ndarray, shape (n_samples, 2)  [only if return_confidence]
            Probability estimates [P(non-member), P(member)].
        """
        if not self._is_trained:
            raise RuntimeError("Call .execute() before .attack().")

        # Step 1: Get victim model's confidence scores on the target data
        confidence_scores = self.victim_model_api.predict(data)  # (n, num_classes)
        confidence_scores = np.asarray(confidence_scores)

        if confidence_scores.ndim == 1:
            confidence_scores = confidence_scores.reshape(1, -1)

        # Step 2: Feed confidence scores into the attack model
        predictions = self.attack_model.predict(confidence_scores)

        if return_confidence:
            if hasattr(self.attack_model, "predict_proba"):
                proba = self.attack_model.predict_proba(confidence_scores)
            else:
                # For SVM without probability=True, fall back to decision_function
                proba = self.attack_model.decision_function(confidence_scores)
            return predictions, proba

        return predictions

    def evaluate(
        self,
        member_data: np.ndarray,
        non_member_data: np.ndarray,
    ) -> dict:
        """Evaluate the attack on known member / non-member data.

        Parameters
        ----------
        member_data : np.ndarray
            Data points known to be IN the victim's training set.
        non_member_data : np.ndarray
            Data points known to be NOT in the victim's training set.

        Returns
        -------
        metrics : dict with keys 'accuracy', 'precision', 'recall', 'f1'.
        """
        # Handle both numeric arrays (vstack) and object arrays (concatenate)
        if member_data.dtype.kind in ("U", "O") or non_member_data.dtype.kind in ("U", "O"):
            X = np.concatenate([member_data, non_member_data])
        else:
            X = np.vstack([member_data, non_member_data])
        y_true = np.concatenate([
            np.ones(len(member_data)),
            np.zeros(len(non_member_data)),
        ])

        y_pred = self.attack(X)

        return {
            "accuracy": accuracy_score(y_true, y_pred),
            "precision": precision_score(y_true, y_pred, zero_division=0),
            "recall": recall_score(y_true, y_pred, zero_division=0),
            "f1": f1_score(y_true, y_pred, zero_division=0),
        }

    # ------------------------------------------------------------------
    # Step 1 – Train shadow models
    # ------------------------------------------------------------------
    def _train_shadow_models(self):
        rng = np.random.RandomState(self.random_state)
        n = len(self.unlabelled_data)

        for i in range(self.num_shadow_models):
            # --- Sample training data for this shadow model ---
            train_indices = rng.choice(
                n, size=self.shadow_model_dataset_size, replace=False
            )
            train_data = self.unlabelled_data[train_indices]

            # --- Query victim API to get labels ---
            # The victim API returns multi-label sigmoid scores.
            # We derive hard multi-hot labels via thresholding (>0.5)
            # so the shadow model can be trained supervised.
            confidence_scores = self.victim_model_api.predict(train_data)
            labels = (confidence_scores > 0.5).astype(np.float32)

            # --- Train shadow model ---
            if isinstance(self.shadow_model_parameters, list):
                param = self.shadow_model_parameters[i % len(self.shadow_model_parameters)]
            else:
                param = self.shadow_model_parameters

            shadow_model = param.build(random_state=self.random_state + i)
            shadow_model.fit(train_data, labels)

            self.shadow_models[i] = {
                "model": shadow_model,
                "train_indices": set(train_indices.tolist()),
            }
            
            # Use getattr to safely print architecture if it's a PyTorch wrapper
            model_name = getattr(shadow_model, "architecture", param.model_type)
            print(f"  Shadow model {i + 1}/{self.num_shadow_models} trained "
                  f"({model_name}).")

    # ------------------------------------------------------------------
    # Step 2 – Prepare the attack dataset
    # ------------------------------------------------------------------
    def _prepare_attack_dataset(self):
        """Build ``self.attack_dataset`` (a pd.DataFrame) with columns:

            class_0, class_1, …, class_{K-1}, is_part_of_dataset

        where each row is the shadow-model confidence vector for a sample,
        and ``is_part_of_dataset`` indicates whether that sample was in the
        shadow model's training set.
        """
        n = len(self.unlabelled_data)
        all_indices = set(range(n))

        # How many positive & negative samples per shadow model
        if self.attack_model_dataset_size is not None:
            num_per_model = self.attack_model_dataset_size // (
                2 * self.num_shadow_models
            )
        else:
            # Use half of the shadow model dataset size per shadow model
            num_per_model = self.shadow_model_dataset_size // 2

        rng = np.random.RandomState(self.random_state + 1)

        rows = []  # list of dicts, will become DataFrame

        for idx, info in self.shadow_models.items():
            model = info["model"]
            train_indices = info["train_indices"]
            non_train_indices = all_indices - train_indices

            def _padded_predict_proba(data):
                """predict_proba with padding to always return num_classes columns.

                sklearn's predict_proba only returns columns for classes it saw
                during training. If the shadow model only observed k < num_classes
                classes, we pad the missing columns with zeros.
                """
                raw_proba = model.predict_proba(data)
                
                # If PyTorch model, it directly returns (N, num_classes)
                if hasattr(model, "architecture") or (isinstance(raw_proba, np.ndarray) and raw_proba.ndim == 2 and raw_proba.shape[1] == self.num_classes):
                    return raw_proba
                    
                n_samples = raw_proba.shape[0]

                if raw_proba.shape[1] == self.num_classes:
                    return raw_proba

                # Pad to num_classes columns
                full_proba = np.zeros((n_samples, self.num_classes))
                for col_idx, cls_label in enumerate(model.classes_):
                    if int(cls_label) < self.num_classes:
                        full_proba[:, int(cls_label)] = raw_proba[:, col_idx]
                return full_proba

            # --- Step 2a: Positive samples (in the training set) ---
            pos_pool = list(train_indices)
            k_pos = min(num_per_model, len(pos_pool))
            pos_sample_indices = rng.choice(pos_pool, size=k_pos, replace=False)
            pos_data = self.unlabelled_data[pos_sample_indices]
            pos_confidences = _padded_predict_proba(pos_data)

            for j in range(k_pos):
                row = {
                    f"class_{c}": pos_confidences[j, c]
                    for c in range(self.num_classes)
                }
                row["is_part_of_dataset"] = 1
                rows.append(row)

            # --- Step 2b: Negative samples (NOT in the training set) ---
            neg_pool = list(non_train_indices)
            k_neg = min(num_per_model, len(neg_pool))
            neg_sample_indices = rng.choice(neg_pool, size=k_neg, replace=False)
            neg_data = self.unlabelled_data[neg_sample_indices]
            neg_confidences = _padded_predict_proba(neg_data)

            for j in range(k_neg):
                row = {
                    f"class_{c}": neg_confidences[j, c]
                    for c in range(self.num_classes)
                }
                row["is_part_of_dataset"] = 0
                rows.append(row)

        self.attack_dataset = pd.DataFrame(rows)
        print(
            f"  Attack dataset built: {len(self.attack_dataset)} samples "
            f"({int(self.attack_dataset['is_part_of_dataset'].sum())} positive, "
            f"{int((1 - self.attack_dataset['is_part_of_dataset']).sum())} negative)."
        )

    # ------------------------------------------------------------------
    # Step 3 – Train the attack model
    # ------------------------------------------------------------------
    def _train_attack_model(self):
        feature_cols = [f"class_{c}" for c in range(self.num_classes)]
        X = self.attack_dataset[feature_cols].values
        y = self.attack_dataset["is_part_of_dataset"].values

        self.attack_model = self.attack_model_parameters.build(
            random_state=self.random_state
        )
        self.attack_model.fit(X, y)
        print(f"  Attack model trained ({self.attack_model_parameters.model_type}).")

    # ------------------------------------------------------------------
    # Convenience repr
    # ------------------------------------------------------------------
    def __repr__(self):
        status = "trained" if self._is_trained else "not trained"
        return (
            f"MIA(num_classes={self.num_classes}, "
            f"num_shadow_models={self.num_shadow_models}, "
            f"shadow={self.shadow_model_parameters!r}, "
            f"attack={self.attack_model_parameters!r}, "
            f"status={status})"
        )

