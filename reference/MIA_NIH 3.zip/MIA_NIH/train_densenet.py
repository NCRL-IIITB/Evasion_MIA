import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MultiLabelBinarizer
import os
from PIL import Image
import matplotlib.pyplot as plt
from tqdm import tqdm
import warnings
warnings.filterwarnings('ignore')

# Device configuration
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {device}")

# Hyperparameters
BATCH_SIZE = 64
EPOCHS = 50
LEARNING_RATE = 1e-4
WEIGHT_DECAY = 1e-5
IMAGE_SIZE = 224
TRAIN_VAL_TEST_SPLIT = (0.7, 0.15, 0.15)  # 70% train, 15% val, 15% test

# Disease classes
DISEASE_CLASSES = [
    'Atelectasis', 'Consolidation', 'Infiltration', 'Pneumothorax', 'Edema',
    'Emphysema', 'Fibrosis', 'Effusion', 'Pneumonia', 'Pleural_thickening',
    'Cardiomegaly', 'Nodule', 'Mass', 'Hernia', 'No Finding'
]

class ChestXRayDataset(Dataset):
    """Custom Dataset for Chest X-Ray images"""
    def __init__(self, image_paths, labels, transform=None):
        self.image_paths = image_paths
        self.labels = labels
        self.transform = transform
    
    def __len__(self):
        return len(self.image_paths)
    
    def __getitem__(self, idx):
        # Load image
        img_path = self.image_paths[idx]
        image = Image.open(img_path).convert('RGB')
        
        if self.transform:
            image = self.transform(image)
        
        # Get label
        label = self.labels[idx]
        
        return image, torch.tensor(label, dtype=torch.float32)


def load_and_prepare_data(xlsx_path, images_dir):
    """Load data from Excel and prepare train/val/test splits"""
    print("Loading data from Excel file...")
    
    # Read Excel file
    df = pd.read_excel(xlsx_path)
    
    # Parse multi-label findings (comma-separated)
    mlb = MultiLabelBinarizer(classes=DISEASE_CLASSES)
    
    image_paths = []
    labels_list = []
    
    for idx, row in df.iterrows():
        # Get image path
        img_name = row['Image Index']
        img_path = os.path.join(images_dir, img_name)
        
        # Check if image exists
        if not os.path.exists(img_path):
            print(f"Warning: Image not found: {img_path}")
            continue
        
        image_paths.append(img_path)
        
        # Parse findings (handle both single and multiple findings)
        findings = str(row['Finding Labels']).split('|')
        findings = [f.strip() for f in findings]
        
        # Create binary label vector
        label_vector = []
        for disease in DISEASE_CLASSES:
            label_vector.append(1 if disease in findings else 0)
        labels_list.append(label_vector)
    
    image_paths = np.array(image_paths)
    labels_array = np.array(labels_list)
    
    print(f"Total samples: {len(image_paths)}")
    
    # Split: train (70%), temp (30%)
    train_idx, temp_idx = train_test_split(
        np.arange(len(image_paths)), 
        test_size=0.30, 
        random_state=42
    )
    
    # Split temp: val (50%), test (50%)
    val_idx, test_idx = train_test_split(
        temp_idx, 
        test_size=0.50, 
        random_state=42
    )
    
    train_images = image_paths[train_idx]
    train_labels = labels_array[train_idx]
    
    val_images = image_paths[val_idx]
    val_labels = labels_array[val_idx]
    
    test_images = image_paths[test_idx]
    test_labels = labels_array[test_idx]
    
    print(f"Train set: {len(train_images)}")
    print(f"Validation set: {len(val_images)}")
    print(f"Test set: {len(test_images)}")
    
    return train_images, train_labels, val_images, val_labels, test_images, test_labels


def create_data_loaders(train_images, train_labels, val_images, val_labels, test_images, test_labels):
    """Create data loaders with augmentation"""
    
    # Data augmentation for training
    train_transform = transforms.Compose([
        transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.RandomRotation(15),
        transforms.ColorJitter(brightness=0.2, contrast=0.2),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225]
        )
    ])
    
    # No augmentation for validation and test
    val_test_transform = transforms.Compose([
        transforms.Resize((IMAGE_SIZE, IMAGE_SIZE)),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225]
        )
    ])
    
    # Create datasets
    train_dataset = ChestXRayDataset(train_images, train_labels, transform=train_transform)
    val_dataset = ChestXRayDataset(val_images, val_labels, transform=val_test_transform)
    test_dataset = ChestXRayDataset(test_images, test_labels, transform=val_test_transform)
    
    # Create data loaders
    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=4)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=4)
    test_loader = DataLoader(test_dataset, batch_size=BATCH_SIZE, shuffle=False, num_workers=4)
    
    return train_loader, val_loader, test_loader


def create_model(num_classes=15):
    """Create DenseNet-121 model for multi-label classification"""
    model = models.densenet121(pretrained=True)
    
    # Modify classifier for multi-label classification
    num_features = model.classifier.in_features
    model.classifier = nn.Sequential(
        nn.Linear(num_features, 512),
        nn.ReLU(),
        nn.Dropout(0.3),
        nn.Linear(512, num_classes)
    )
    
    return model


def train_epoch(model, train_loader, criterion, optimizer, device):
    """Train for one epoch"""
    model.train()
    total_loss = 0.0
    
    for images, labels in tqdm(train_loader, desc="Training"):
        images = images.to(device)
        labels = labels.to(device)
        
        # Forward pass
        outputs = model(images)
        loss = criterion(outputs, labels)
        
        # Backward pass
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
        total_loss += loss.item()
    
    avg_loss = total_loss / len(train_loader)
    return avg_loss


def validate(model, val_loader, criterion, device):
    """Validate the model"""
    model.eval()
    total_loss = 0.0
    all_preds = []
    all_labels = []
    
    with torch.no_grad():
        for images, labels in tqdm(val_loader, desc="Validating"):
            images = images.to(device)
            labels = labels.to(device)
            
            outputs = model(images)
            loss = criterion(outputs, labels)
            
            total_loss += loss.item()
            
            # Store predictions and labels
            preds = (torch.sigmoid(outputs) > 0.5).cpu().numpy()
            all_preds.append(preds)
            all_labels.append(labels.cpu().numpy())
    
    avg_loss = total_loss / len(val_loader)
    
    # Calculate metrics
    all_preds = np.concatenate(all_preds, axis=0)
    all_labels = np.concatenate(all_labels, axis=0)
    
    # Hamming loss (fraction of labels that are incorrect)
    hamming_loss = np.mean(all_preds != all_labels)
    
    # Accuracy (exact match ratio)
    accuracy = np.mean(np.all(all_preds == all_labels, axis=1))
    
    return avg_loss, hamming_loss, accuracy


def test(model, test_loader, device):
    """Evaluate on test set"""
    model.eval()
    all_preds = []
    all_labels = []
    
    with torch.no_grad():
        for images, labels in tqdm(test_loader, desc="Testing"):
            images = images.to(device)
            labels = labels.to(device)
            
            outputs = model(images)
            preds = (torch.sigmoid(outputs) > 0.5).cpu().numpy()
            
            all_preds.append(preds)
            all_labels.append(labels.cpu().numpy())
    
    all_preds = np.concatenate(all_preds, axis=0)
    all_labels = np.concatenate(all_labels, axis=0)
    
    # Calculate per-class metrics
    print("\nPer-class Precision, Recall, F1-Score:")
    print("-" * 60)
    
    tp = np.sum((all_preds == 1) & (all_labels == 1), axis=0)
    fp = np.sum((all_preds == 1) & (all_labels == 0), axis=0)
    fn = np.sum((all_preds == 0) & (all_labels == 1), axis=0)
    
    for i, disease in enumerate(DISEASE_CLASSES):
        precision = tp[i] / (tp[i] + fp[i]) if (tp[i] + fp[i]) > 0 else 0
        recall = tp[i] / (tp[i] + fn[i]) if (tp[i] + fn[i]) > 0 else 0
        f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
        
        print(f"{disease:20s} | P: {precision:.3f} | R: {recall:.3f} | F1: {f1:.3f}")
    
    # Overall metrics
    hamming_loss = np.mean(all_preds != all_labels)
    accuracy = np.mean(np.all(all_preds == all_labels, axis=1))
    
    print("-" * 60)
    print(f"Hamming Loss: {hamming_loss:.4f}")
    print(f"Accuracy (exact match): {accuracy:.4f}")


def main():
    """Main training pipeline"""
    
    # Paths
    xlsx_path = "dataset.xlsx"
    images_dir = "images"
    model_save_path = "densenet121_chest_xray.pth"
    
    # Check if data exists
    if not os.path.exists(xlsx_path):
        print(f"Error: {xlsx_path} not found!")
        return
    
    if not os.path.exists(images_dir):
        print(f"Error: {images_dir} directory not found!")
        return
    
    # Load and prepare data
    train_images, train_labels, val_images, val_labels, test_images, test_labels = \
        load_and_prepare_data(xlsx_path, images_dir)
    
    # Create data loaders
    train_loader, val_loader, test_loader = \
        create_data_loaders(train_images, train_labels, val_images, val_labels, test_images, test_labels)
    
    # Create model
    print("\nCreating DenseNet-121 model...")
    model = create_model(num_classes=len(DISEASE_CLASSES))
    model = model.to(device)
    
    # Loss function (BCEWithLogitsLoss for multi-label classification)
    criterion = nn.BCEWithLogitsLoss()
    
    # Optimizer
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE, weight_decay=WEIGHT_DECAY)
    
    # Learning rate scheduler
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=0.5, patience=5, 
    )
    
    # Training loop
    print("\nStarting training...")
    best_val_loss = float('inf')
    patience = 10
    patience_counter = 0
    
    train_losses = []
    val_losses = []
    
    for epoch in range(EPOCHS):
        print(f"\nEpoch [{epoch+1}/{EPOCHS}]")
        
        # Train
        train_loss = train_epoch(model, train_loader, criterion, optimizer, device)
        train_losses.append(train_loss)
        print(f"Train Loss: {train_loss:.4f}")
        
        # Validate
        val_loss, hamming_loss, accuracy = validate(model, val_loader, criterion, device)
        val_losses.append(val_loss)
        print(f"Val Loss: {val_loss:.4f} | Hamming Loss: {hamming_loss:.4f} | Accuracy: {accuracy:.4f}")
        
        # Learning rate scheduler
        scheduler.step(val_loss)
        
        # Save best model
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            patience_counter = 0
            torch.save(model.state_dict(), model_save_path)
            print(f"Best model saved with val loss: {val_loss:.4f}")
        else:
            patience_counter += 1
        
        # Early stopping
        if patience_counter >= patience:
            print(f"\nEarly stopping after {epoch+1} epochs")
            break
    
    # Load best model
    print(f"\nLoading best model from {model_save_path}...")
    model.load_state_dict(torch.load(model_save_path))
    
    # Test
    print("\n" + "="*60)
    print("TEST SET EVALUATION")
    print("="*60)
    test(model, test_loader, device)
    
    # Plot training history
    plt.figure(figsize=(10, 6))
    plt.plot(train_losses, label='Train Loss')
    plt.plot(val_losses, label='Validation Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.title('Training and Validation Loss')
    plt.legend()
    plt.grid(True)
    plt.savefig('training_history.png')
    print("\nTraining history saved as 'training_history.png'")


if __name__ == "__main__":
    main()
