"""
prepare_nih_dataset.py
======================
Download images from the first 2 NIH Chest X-ray zip archives on HuggingFace,
extract them into a common images/ folder, and build a manifest CSV for the
MIA pipeline using the user-provided dataset.xlsx for labels.

Output:
  - images/              <- extracted PNGs from both folders
  - nih_manifest.csv     <- columns: path, label, label_idx, split
"""

import os
import sys
import zipfile
import shutil
import urllib.request
from collections import Counter
import numpy as np
import pandas as pd

# -------------------- Configuration --------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
IMG_DIR = os.path.join(BASE_DIR, "images")          # <-- train_densenet.py expects "images/"
LABEL_CSV_PATH = os.path.join(BASE_DIR, "Data_Entry_2017.csv")
MANIFEST_PATH = os.path.join(BASE_DIR, "nih_manifest.csv")

HF_BASE = "https://huggingface.co/datasets/alkzar90/NIH-Chest-X-ray-dataset/resolve/main/data"
ZIP_URLS = [
    f"{HF_BASE}/images/images_001.zip",
    f"{HF_BASE}/images/images_002.zip",
]
ZIP_PATHS = [
    os.path.join(DATA_DIR, "images_001.zip"),
    os.path.join(DATA_DIR, "images_002.zip"),
]
LABEL_URL = f"{HF_BASE}/Data_Entry_2017_v2020.csv"

# Disease classes (same order as train_densenet.py)
DISEASE_CLASSES = [
    'Atelectasis', 'Consolidation', 'Infiltration', 'Pneumothorax', 'Edema',
    'Emphysema', 'Fibrosis', 'Effusion', 'Pneumonia', 'Pleural_thickening',
    'Cardiomegaly', 'Nodule', 'Mass', 'Hernia', 'No Finding'
]
NUM_CLASSES = len(DISEASE_CLASSES)  # 15

# Member / Non-member split ratio
MEMBER_RATIO = 0.50  # 50% members, 50% non-members
RANDOM_SEED = 42


# -------------------- Helpers --------------------
def _download_with_progress(url: str, dest: str):
    """Download a file with a simple progress indicator."""
    if os.path.exists(dest):
        size_mb = os.path.getsize(dest) / (1024 * 1024)
        print(f"  Already present: {dest} ({size_mb:.1f} MB) — skipping download.")
        return

    print(f"  Downloading: {url}")
    print(f"          ->: {dest}")

    last_pct = [-1]

    def _hook(block_num, block_size, total_size):
        if total_size <= 0:
            return
        downloaded = block_num * block_size
        pct = min(100, int(downloaded * 100 / total_size))
        if pct != last_pct[0] and pct % 5 == 0:
            mb_done = downloaded / (1024 * 1024)
            mb_total = total_size / (1024 * 1024)
            print(f"    {pct:3d}%  ({mb_done:7.1f} / {mb_total:7.1f} MB)")
            sys.stdout.flush()
            last_pct[0] = pct

    urllib.request.urlretrieve(url, dest, reporthook=_hook)
    print(f"  Done: {os.path.getsize(dest) / (1024 * 1024):.1f} MB")


def _extract_zip(zip_path: str, extract_to: str):
    """Extract a zip file, flattening any nested 'images/' folder."""
    os.makedirs(extract_to, exist_ok=True)

    print(f"  Extracting {zip_path} -> {extract_to}")

    with zipfile.ZipFile(zip_path, "r") as zf:
        members = zf.namelist()
        png_members = [m for m in members if m.lower().endswith(".png")]
        print(f"    {len(png_members)} PNG files in archive.")
        for i, m in enumerate(png_members):
            target_name = os.path.basename(m)
            if not target_name:
                continue
            target_path = os.path.join(extract_to, target_name)
            if os.path.exists(target_path):
                continue  # skip already extracted
            with zf.open(m) as src, open(target_path, "wb") as dst:
                shutil.copyfileobj(src, dst)
            if (i + 1) % 1000 == 0:
                print(f"    extracted {i + 1}/{len(png_members)}")
                sys.stdout.flush()
    print(f"  Done. Files in {extract_to}: {len(os.listdir(extract_to))}")


# -------------------- Main pipeline --------------------
def main():
    os.makedirs(DATA_DIR, exist_ok=True)

    # 1) Download both zip files
    print("[1/4] Downloading data ...")
    for z_url, z_path in zip(ZIP_URLS, ZIP_PATHS):
        _download_with_progress(z_url, z_path)

    # 2) Extract images into a common images/ folder
    print("\n[2/4] Extracting images ...")
    existing_count = len(os.listdir(IMG_DIR)) if os.path.exists(IMG_DIR) else 0
    if existing_count > 9000:
        print(f"  Already extracted: {IMG_DIR} ({existing_count} files) — skipping.")
    else:
        for z_path in ZIP_PATHS:
            _extract_zip(z_path, IMG_DIR)

    # 3) Build multi-label manifest from the label CSV
    print("\n[3/4] Building multi-label manifest ...")

    df = pd.read_csv(LABEL_CSV_PATH)
    print(f"  Label CSV rows: {len(df)}")

    # Filter to images that actually exist in the images/ folder
    available_images = set(os.listdir(IMG_DIR))
    df = df[df["Image Index"].isin(available_images)].copy()
    print(f"  Rows matching extracted images: {len(df)}")

    if len(df) == 0:
        print("  ERROR: No matching images found! Check that dataset.xlsx "
              "image names match the extracted PNGs.")
        sys.exit(1)

    # Build multi-hot label vectors (same order as DISEASE_CLASSES)
    label_to_idx = {name: i for i, name in enumerate(DISEASE_CLASSES)}

    def _get_multi_labels(finding_str: str):
        labels = [0] * NUM_CLASSES
        for tag in str(finding_str).split("|"):
            tag = tag.strip()
            if tag in label_to_idx:
                labels[label_to_idx[tag]] = 1
        return labels

    df["label_idx"] = df["Finding Labels"].apply(_get_multi_labels)
    df["label"] = df["Finding Labels"]

    # Print class distribution
    print(f"\n  Disease distribution ({NUM_CLASSES} classes):")
    label_counter = Counter()
    for finding in df["Finding Labels"]:
        for tag in str(finding).split("|"):
            tag = tag.strip()
            if tag in label_to_idx:
                label_counter[tag] += 1
    for name in DISEASE_CLASSES:
        print(f"    {name:25s}  {label_counter.get(name, 0):6d}")

    # 4) Random split into member / non-member
    print(f"\n[4/4] Splitting into member / non-member ...")
    df = df.sample(frac=1.0, random_state=RANDOM_SEED).reset_index(drop=True)

    n_m = int(len(df) * MEMBER_RATIO)
    member_df = df.iloc[:n_m].copy()
    nonmember_df = df.iloc[n_m:].copy()

    member_df["split"] = "member"
    nonmember_df["split"] = "nonmember"

    print(f"    Members:     {len(member_df)}")
    print(f"    Non-members: {len(nonmember_df)}")

    # Build manifest
    manifest = pd.concat([member_df, nonmember_df], ignore_index=True)
    manifest["path"] = manifest["Image Index"].apply(
        lambda fn: os.path.join(IMG_DIR, fn)
    )
    manifest = manifest[["path", "label", "label_idx", "split"]]
    manifest.to_csv(MANIFEST_PATH, index=False)

    print(f"\n[DONE] Manifest written to {MANIFEST_PATH}")
    print(f"  Total images: {len(manifest)}")
    print(f"  Columns: {list(manifest.columns)}")


if __name__ == "__main__":
    main()
