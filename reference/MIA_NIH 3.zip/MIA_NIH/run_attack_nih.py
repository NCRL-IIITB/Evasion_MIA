"""
run_attack_nih.py
=================
Variance-Enhanced Membership Inference Attack on the NIH Chest X-ray
DenseNet-121 victim model.

Comparing two attack strategies:
  1. Standard Shadow Model MIA (Baseline)
  2. Variance-Enhanced Shadow Model MIA (Novel Variant)

Pre-conditions:
  * nih_manifest.csv  (run prepare_nih_dataset.py)
  * nih_victim.pth    (run train_nih_victim.py)

Usage:
    python run_attack_nih.py
"""

import os
import sys
import time
import json
import numpy as np
import pandas as pd

# -------------------- Configuration --------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MANIFEST_PATH = os.path.join(BASE_DIR, "nih_manifest.csv")
MODEL_PATH = os.path.join(BASE_DIR, "nih_victim.pth")
META_PATH = os.path.join(BASE_DIR, "nih_victim_meta.json")
RESULTS_PATH = os.path.join(BASE_DIR, "attack_results_nih.txt")

NUM_SHADOW_MODELS = 8
SHADOW_DATASET_SIZE = 2500
RANDOM_SEED = 42

# How many of each split to hold out for FINAL evaluation
NUM_EVAL_MEMBERS = 2000
NUM_EVAL_NONMEMBERS = 2000

# How many of each split to put in the unlabelled pool for shadow training
# Pool size determines how much "training-like" signal the shadow models see.
NUM_POOL_MEMBERS = 3000
NUM_POOL_NONMEMBERS = 3000


# -------------------- Helpers --------------------
def print_banner(text: str):
    print()
    print("=" * 70)
    print(f"  {text}")
    print("=" * 70)


def load_manifest():
    if not os.path.exists(MANIFEST_PATH):
        print(f"ERROR: {MANIFEST_PATH} not found. Run prepare_nih_dataset.py first.")
        sys.exit(1)
    if not os.path.exists(MODEL_PATH):
        print(f"ERROR: {MODEL_PATH} not found. Run train_nih_victim.py first.")
        sys.exit(1)

    df = pd.read_csv(MANIFEST_PATH)
    member_paths = df[df["split"] == "member"]["path"].values
    nonmember_paths = df[df["split"] == "nonmember"]["path"].values
    print(f"[DATA] Members:     {len(member_paths)}")
    print(f"[DATA] Non-members: {len(nonmember_paths)}")
    return member_paths, nonmember_paths


# -------------------- Attack 1: Baseline Shadow MIA --------------------
def run_baseline_shadow_attack(api, pool_paths, eval_member_paths, eval_nonmember_paths,
                               num_classes: int):
    from mia import MIA, ModelParameters

    print_banner("ATTACK 1: STANDARD SHADOW MODEL MIA (BASELINE)")

    shadow_architectures = ["resnet18", "mobilenet_v3_small", "efficientnet_b0"]
    shadow_params_list = [
        ModelParameters("pytorch_cnn", architecture=arch, num_classes=num_classes, epochs=15, batch_size=32, lr=1e-3)
        for arch in shadow_architectures
    ]

    mia = MIA(
        victim_model_api=api,
        unlabelled_data=pool_paths,
        num_classes=num_classes,
        num_shadow_models=NUM_SHADOW_MODELS,
        shadow_model_dataset_size=SHADOW_DATASET_SIZE,
        shadow_model_parameters=shadow_params_list,
        attack_model_parameters=ModelParameters(
            "gradient_boosting", n_estimators=100, learning_rate=0.1
        ),
    )
    mia.execute()

    print("\n[STEP 2] Evaluating on held-out data ...")
    metrics = mia.evaluate(eval_member_paths, eval_nonmember_paths)

    print(f"\n  Baseline Shadow MIA Results:")
    print(f"    Accuracy:  {metrics['accuracy']:.4f}")
    print(f"    Precision: {metrics['precision']:.4f}")
    print(f"    Recall:    {metrics['recall']:.4f}")
    print(f"    F1 Score:  {metrics['f1']:.4f}")

    return {
        "Model": "Baseline Shadow Model (Gradient Boosting)",
        "Accuracy": metrics["accuracy"],
        "Precision": metrics["precision"],
        "Recall": metrics["recall"],
        "F1": metrics["f1"],
    }


# -------------------- Attack 2: Variance-Enhanced Shadow MIA --------------------
def run_variance_shadow_attack(api, pool_paths, eval_member_paths, eval_nonmember_paths,
                               num_classes: int):
    from mia_variance import VarianceMIA
    from mia import ModelParameters

    print_banner("ATTACK 2: VARIANCE-ENHANCED SHADOW MODEL MIA")

    shadow_architectures = ["resnet18", "mobilenet_v3_small", "efficientnet_b0"]
    shadow_params_list = [
        ModelParameters("pytorch_cnn", architecture=arch, num_classes=num_classes, epochs=15, batch_size=32, lr=1e-3)
        for arch in shadow_architectures
    ]

    vmia = VarianceMIA(
        victim_model_api=api,
        unlabelled_data=pool_paths,
        num_classes=num_classes,
        num_shadow_models=NUM_SHADOW_MODELS,
        shadow_model_dataset_size=SHADOW_DATASET_SIZE,
        shadow_model_parameters=shadow_params_list,
        attack_model_parameters=ModelParameters(
            "gradient_boosting", n_estimators=100, learning_rate=0.1
        ),
    )
    vmia.execute()

    print("\n  Attack dataset sample (first 3 rows):")
    print(vmia.attack_dataset.head(3).to_string(index=False))

    print("\n[STEP 2] Evaluating on held-out data ...")
    metrics = vmia.evaluate(eval_member_paths, eval_nonmember_paths)

    print(f"\n  VarianceMIA Results:")
    print(f"    Accuracy:  {metrics['accuracy']:.4f}")
    print(f"    Precision: {metrics['precision']:.4f}")
    print(f"    Recall:    {metrics['recall']:.4f}")
    print(f"    F1 Score:  {metrics['f1']:.4f}")

    return {
        "Model": "Variance Shadow Model (Gradient Boosting)",
        "Accuracy": metrics["accuracy"],
        "Precision": metrics["precision"],
        "Recall": metrics["recall"],
        "F1": metrics["f1"],
    }


# -------------------- Main --------------------
def main():
    print_banner("Shadow Model MIA on NIH Chest X-ray CNN")

    # 1. Load splits
    print("\n[SETUP] Loading manifest ...")
    member_paths_all, nonmember_paths_all = load_manifest()

    # 2. Load metadata to get num_classes
    if not os.path.exists(META_PATH):
        print(f"ERROR: {META_PATH} not found. Re-run train_nih_victim.py.")
        sys.exit(1)
    with open(META_PATH, "r") as f:
        meta = json.load(f)
    num_classes = int(meta["num_classes"])
    print(f"[SETUP] Victim has {num_classes} classes: {meta['label_names']}")
    print(f"[SETUP] Victim train_acc={meta.get('final_train_acc'):.4f}  "
          f"val_acc={meta.get('final_val_acc'):.4f}  "
          f"gap={(meta.get('memorization_gap') or 0) * 100:+.2f}%")

    # 3. Sample pool (mixed 50/50 members + non-members) and eval sets (disjoint)
    rng = np.random.RandomState(RANDOM_SEED)

    # Reserve at least 33% of the available paths for evaluation
    max_pool_m = int(len(member_paths_all) * 0.66)
    max_pool_nm = int(len(nonmember_paths_all) * 0.66)

    n_pool_m = min(NUM_POOL_MEMBERS, max_pool_m)
    n_pool_nm = min(NUM_POOL_NONMEMBERS, max_pool_nm)

    member_indices = rng.permutation(len(member_paths_all))
    nonmember_indices = rng.permutation(len(nonmember_paths_all))

    pool_member_idx = member_indices[:n_pool_m]
    pool_nonmember_idx = nonmember_indices[:n_pool_nm]

    n_eval_m = min(NUM_EVAL_MEMBERS, len(member_paths_all) - n_pool_m)
    n_eval_nm = min(NUM_EVAL_NONMEMBERS, len(nonmember_paths_all) - n_pool_nm)
    eval_member_idx = member_indices[n_pool_m: n_pool_m + n_eval_m]
    eval_nonmember_idx = nonmember_indices[n_pool_nm: n_pool_nm + n_eval_nm]

    pool_member_paths = member_paths_all[pool_member_idx]
    pool_nonmember_paths = nonmember_paths_all[pool_nonmember_idx]
    eval_member_paths = member_paths_all[eval_member_idx]
    eval_nonmember_paths = nonmember_paths_all[eval_nonmember_idx]

    pool_all = np.concatenate([pool_member_paths, pool_nonmember_paths])
    rng.shuffle(pool_all)

    print(f"\n[SETUP] Pool size:      {len(pool_all)} "
          f"({n_pool_m} member + {n_pool_nm} nonmember, shuffled)")
    print(f"[SETUP] Eval members:    {len(eval_member_paths)}")
    print(f"[SETUP] Eval nonmembers: {len(eval_nonmember_paths)}")

    # 4. Load API and pre-compute all scores for DIAGNOSTICS ONLY
    print(f"\n[SETUP] Loading victim model ({num_classes} classes) ...")
    from api_nih import NIHChestAPI
    api = NIHChestAPI(MODEL_PATH, num_classes=num_classes, batch_size=32)
    print(f"[SETUP] Inference device: {api.device}")

    print("\n[SETUP] Pre-computing victim scores for evaluation set diagnostics ...")
    t0 = time.time()
    eval_member_scores = api.predict(np.array(eval_member_paths, dtype=object))
    eval_nonmember_scores = api.predict(np.array(eval_nonmember_paths, dtype=object))
    print(f"  {len(eval_member_paths) + len(eval_nonmember_paths)} eval images "
          f"queried in {time.time() - t0:.1f}s")

    # Sanity: how confident is the victim on members vs non-members?
    # Max confidence across multi-label sigmoids
    pool_max_member_conf = np.max(eval_member_scores[:50], axis=1).mean()
    pool_max_nonmember_conf = np.max(eval_nonmember_scores, axis=1).mean()
    print(f"\n[DIAG] Mean max-confidence on members:     {pool_max_member_conf:.4f}")
    print(f"[DIAG] Mean max-confidence on non-members: {pool_max_nonmember_conf:.4f}")
    print(f"[DIAG] Confidence gap (member - nonmember): "
          f"{pool_max_member_conf - pool_max_nonmember_conf:+.4f}  "
          f"(positive = MIA signal exists)")

    total_start = time.time()

    # 5. Run both attacks
    baseline_result = run_baseline_shadow_attack(
        api, pool_all, eval_member_paths, eval_nonmember_paths, num_classes
    )
    variance_result = run_variance_shadow_attack(
        api, pool_all, eval_member_paths, eval_nonmember_paths, num_classes
    )

    total_time = time.time() - total_start

    # 6. Final comparison table (matching brain tumor runner format)
    print_banner("FINAL COMPARISON: BASELINE vs VARIANCE-ENHANCED (SHADOW MODELS)")

    all_results = [baseline_result, variance_result]

    print(f"\n  {'Attack Method':<45s}  {'Acc':>7s}  {'Prec':>7s}  {'Rec':>7s}  {'F1':>7s}")
    print("  " + "-" * 75)
    for r in all_results:
        print(f"  {r['Model']:<45s}  {r['Accuracy']:7.4f}  "
              f"{r['Precision']:7.4f}  {r['Recall']:7.4f}  {r['F1']:7.4f}")

    print(f"\n  Random baseline: 0.5000")
    print(f"  Total attack runtime: {total_time:.1f}s")

    # 7. Save results to file
    with open(RESULTS_PATH, "w") as f:
        f.write("NIH Chest X-ray Shadow Model Variance-Enhanced MIA Results\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"Victim Model:      Overfitted ResNet-18 (PyTorch)\n")
        f.write(f"Dataset:           NIH ChestX-ray14 (alkzar90/HF mirror)\n")
        f.write(f"Num classes:       {num_classes}\n")
        f.write(f"Class labels:      {meta['label_names']}\n")
        f.write(f"Victim train_acc:  {meta.get('final_train_acc'):.4f}\n")
        f.write(f"Victim val_acc:    {meta.get('final_val_acc'):.4f}\n")
        f.write(f"Memorization gap:  {(meta.get('memorization_gap') or 0)*100:+.2f}%\n")
        f.write(f"Shadow Models:     {NUM_SHADOW_MODELS}\n")
        f.write(f"Pool size:         {len(pool_all)}\n\n")

        f.write(f"{'Attack Method':<45s}  {'Acc':>7s}  {'Prec':>7s}  {'Rec':>7s}  {'F1':>7s}\n")
        f.write("-" * 75 + "\n")
        for r in all_results:
            f.write(f"{r['Model']:<45s}  {r['Accuracy']:7.4f}  "
                    f"{r['Precision']:7.4f}  {r['Recall']:7.4f}  {r['F1']:7.4f}\n")

    print(f"\n  Results saved to {RESULTS_PATH}")


if __name__ == "__main__":
    main()
