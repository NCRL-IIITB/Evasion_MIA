import torch
import torch.nn as nn
from torchvision import models, transforms
from torch.utils.data import Dataset, DataLoader
from PIL import Image
import numpy as np

class ShadowDataset(Dataset):
    def __init__(self, paths, labels, transform):
        self.paths = paths
        self.labels = labels
        self.transform = transform

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, idx):
        path = self.paths[idx]
        try:
            img = Image.open(path).convert("RGB")
            img = self.transform(img)
        except Exception:
            img = torch.zeros(3, 224, 224)
            
        label = self.labels[idx]
        return img, torch.tensor(label, dtype=torch.float32)

class InferenceDataset(Dataset):
    def __init__(self, paths, transform):
        self.paths = paths
        self.transform = transform

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, idx):
        path = self.paths[idx]
        try:
            img = Image.open(path).convert("RGB")
            img = self.transform(img)
        except Exception:
            img = torch.zeros(3, 224, 224)
        return img

class PyTorchShadowModel:
    """Wrapper that makes a PyTorch CNN act like an sklearn classifier for MIA."""
    def __init__(self, architecture="resnet18", num_classes=4, epochs=3, batch_size=32, lr=1e-3, random_state=42):
        self.architecture = architecture
        self.num_classes = num_classes
        self.epochs = epochs
        self.batch_size = batch_size
        self.lr = lr
        self.random_state = random_state
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = None

        self.transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
        ])

    def _build_model(self):
        torch.manual_seed(self.random_state)
        
        if self.architecture == "resnet18":
            model = models.resnet18(weights=models.ResNet18_Weights.IMAGENET1K_V1)
            model.fc = nn.Linear(model.fc.in_features, self.num_classes)
        elif self.architecture == "mobilenet_v3_small":
            model = models.mobilenet_v3_small(weights=models.MobileNet_V3_Small_Weights.IMAGENET1K_V1)
            model.classifier[3] = nn.Linear(model.classifier[3].in_features, self.num_classes)
        elif self.architecture == "densenet121":
            model = models.densenet121(weights=models.DenseNet121_Weights.IMAGENET1K_V1)
            in_features = model.classifier.in_features
            model.classifier = nn.Sequential(
                nn.Linear(in_features, 512),
                nn.ReLU(),
                nn.Linear(512, self.num_classes)
            )
        elif self.architecture == "efficientnet_b0":
            model = models.efficientnet_b0(weights=models.EfficientNet_B0_Weights.IMAGENET1K_V1)
            model.classifier[1] = nn.Linear(model.classifier[1].in_features, self.num_classes)
        else:
            raise ValueError(f"Unsupported architecture: {self.architecture}")
            
        return model.to(self.device)

    def fit(self, X, y):
        # X: array of image paths
        # y: 2D array of multi-hot labels (N, num_classes)
        self.model = self._build_model()
        self.model.train()
        
        dataset = ShadowDataset(X, y, self.transform)
        loader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True, num_workers=2, pin_memory=True if self.device.type=="cuda" else False)
        
        optimizer = torch.optim.Adam(self.model.parameters(), lr=self.lr)
        criterion = nn.BCEWithLogitsLoss()
        
        import sys
        for epoch in range(self.epochs):
            for batch_idx, (images, labels) in enumerate(loader):
                images, labels = images.to(self.device), labels.to(self.device)
                optimizer.zero_grad()
                logits = self.model(images)
                loss = criterion(logits, labels)
                loss.backward()
                optimizer.step()
                
                # Print progress regularly to keep the HuggingFace connection alive
                if batch_idx % 10 == 0:
                    print(f"      [{self.architecture}] Epoch {epoch+1}/{self.epochs} | Batch {batch_idx}/{len(loader)} | Loss: {loss.item():.4f}")
                    sys.stdout.flush()
        return self

    def predict_proba(self, X):
        # Return sigmoid probabilities
        self.model.eval()
        dataset = InferenceDataset(X, self.transform)
        loader = DataLoader(dataset, batch_size=self.batch_size, shuffle=False, num_workers=2, pin_memory=True if self.device.type=="cuda" else False)
        
        all_probs = []
        with torch.no_grad():
            for images in loader:
                images = images.to(self.device)
                logits = self.model(images)
                probs = torch.sigmoid(logits).cpu().numpy()
                all_probs.append(probs)
                
        # This returns an array of shape (N, num_classes).
        # Note: In mia.py, if the model returns shape (N, num_classes) directly instead of a list of shapes (N, 2),
        # _padded_predict_proba should handle it gracefully, or we bypass it.
        return np.vstack(all_probs)
