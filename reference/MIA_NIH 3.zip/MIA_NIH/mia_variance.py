"""
Variance-Enhanced Membership Inference Attack (VarianceMIA)

A variant of the standard MIA that adds per-class variance of shadow model
outputs as additional features for the attack model.

Intuition:
    When multiple shadow models are queried on the same data point, the
    variance of their confidence scores for each class captures "model
    disagreement."  Combined with the actual confidence scores, this
    gives the attack model richer signal to predict membership:

    - Low variance + high confidence → models agree and are confident
      → data point likely resembles training data (member)
    - High variance → models disagree → uncertain membership
    - Low variance + low confidence → all models agree it's hard
      → likely non-member

Attack dataset columns:
    class_0, …, class_K,            (confidence from relevant shadow model)
    var_class_0, …, var_class_K,     (per-class variance across ALL shadow models)
    is_part_of_dataset              (label)

At attack time:
    - Query the victim model → confidence vector
    - Query all shadow models → compute per-class variance
    - Feed [victim_confidence, shadow_variance] to the attack model
"""

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

from mia import MIA, ModelParameters, API


class VarianceMIA(MIA):
    """Membership Inference Attack with per-class variance features.

    Inherits from MIA and overrides:
      - ``_prepare_attack_dataset()``: adds per-class variance across all
        shadow models as additional features.
      - ``_train_attack_model()``: uses the extended feature set.
      - ``attack()``: queries both victim model and shadow models.
      - ``evaluate()``: uses the extended attack pipeline.

    All constructor parameters are the same as MIA.

    Examples
    --------
    >>> vmia = VarianceMIA(api, data, num_classes=5, num_shadow_models=5)
    >>> vmia.execute()
    >>> preds = vmia.attack(target_data)
    >>> metrics = vmia.evaluate(member_data, non_member_data)
    """

    # ------------------------------------------------------------------
    # Helper: get padded predict_proba from a shadow model
    # ------------------------------------------------------------------
    def _padded_predict_proba(self, model, data):
        """predict_proba with padding to always return num_classes columns."""
        raw_proba = model.predict_proba(data)
        
        # If PyTorch model, it directly returns (N, num_classes)
        if hasattr(model, "architecture") or (isinstance(raw_proba, np.ndarray) and raw_proba.ndim == 2 and raw_proba.shape[1] == self.num_classes):
            return raw_proba
            
        n_samples = raw_proba.shape[0]

        if raw_proba.shape[1] == self.num_classes:
            return raw_proba

        full_proba = np.zeros((n_samples, self.num_classes))
        for col_idx, cls_label in enumerate(model.classes_):
            if int(cls_label) < self.num_classes:
                full_proba[:, int(cls_label)] = raw_proba[:, col_idx]
        return full_proba

    # ------------------------------------------------------------------
    # Helper: compute per-class variance across all shadow models
    # ------------------------------------------------------------------
    def _compute_cross_model_variance(self, data):
        """Query all shadow models on `data` and compute variance of max confidence.

        Parameters
        ----------
        data : np.ndarray, shape (n_samples, n_features)

        Returns
        -------
        variance : np.ndarray, shape (n_samples, 1)
            For each sample, the variance of the maximum confidence score
            across all shadow models.
        stacked_max : np.ndarray, shape (num_shadow_models, n_samples)
            Max confidence scores from each shadow model.
        """
        all_max_scores = []
        for idx, info in self.shadow_models.items():
            model = info["model"]
            scores = self._padded_predict_proba(model, data)
            max_scores = np.max(scores, axis=1) # (n_samples,)
            all_max_scores.append(max_scores)

        # Stack: (num_shadow_models, n_samples)
        stacked_max = np.stack(all_max_scores, axis=0)

        # Variance across shadow models (axis=0) for each sample's max score
        variance = np.var(stacked_max, axis=0)  # (n_samples,)

        return variance.reshape(-1, 1), stacked_max

    # ------------------------------------------------------------------
    # Step 2 – Prepare attack dataset (with variance features)
    # ------------------------------------------------------------------
    def _prepare_attack_dataset(self):
        """Build attack dataset with confidence + variance features.

        Columns:
            class_0, …, class_K,
            var_class_0, …, var_class_K,
            is_part_of_dataset
        """
        n = len(self.unlabelled_data)
        all_indices = set(range(n))

        if self.attack_model_dataset_size is not None:
            num_per_model = self.attack_model_dataset_size // (
                2 * self.num_shadow_models
            )
        else:
            num_per_model = self.shadow_model_dataset_size // 2

        rng = np.random.RandomState(self.random_state + 1)

        rows = []

        for idx, info in self.shadow_models.items():
            model = info["model"]
            train_indices = info["train_indices"]
            non_train_indices = all_indices - train_indices

            # --- Step 2a: Positive samples (in training set) ---
            pos_pool = list(train_indices)
            k_pos = min(num_per_model, len(pos_pool))
            pos_sample_indices = rng.choice(pos_pool, size=k_pos, replace=False)
            pos_data = self.unlabelled_data[pos_sample_indices]

            # Confidence from THIS shadow model
            pos_confidences = self._padded_predict_proba(model, pos_data)

            # Variance of Max Confidence across ALL shadow models
            pos_variance, _ = self._compute_cross_model_variance(pos_data)

            for j in range(k_pos):
                row = {}
                for c in range(self.num_classes):
                    row[f"class_{c}"] = pos_confidences[j, c]
                
                row["variance_of_max"] = pos_variance[j, 0]
                row["is_part_of_dataset"] = 1
                rows.append(row)

            # --- Step 2b: Negative samples (NOT in training set) ---
            neg_pool = list(non_train_indices)
            k_neg = min(num_per_model, len(neg_pool))
            neg_sample_indices = rng.choice(neg_pool, size=k_neg, replace=False)
            neg_data = self.unlabelled_data[neg_sample_indices]

            neg_confidences = self._padded_predict_proba(model, neg_data)
            neg_variance, _ = self._compute_cross_model_variance(neg_data)

            for j in range(k_neg):
                row = {}
                for c in range(self.num_classes):
                    row[f"class_{c}"] = neg_confidences[j, c]
                
                row["variance_of_max"] = neg_variance[j, 0]
                row["is_part_of_dataset"] = 0
                rows.append(row)

        self.attack_dataset = pd.DataFrame(rows)

        # Report
        n_pos = int(self.attack_dataset["is_part_of_dataset"].sum())
        n_neg = len(self.attack_dataset) - n_pos
        n_features = self.num_classes + 1
        print(
            f"  Attack dataset built: {len(self.attack_dataset)} samples "
            f"({n_pos} positive, {n_neg} negative), "
            f"{n_features} features (confidence + variance)."
        )

    # ------------------------------------------------------------------
    # Step 3 – Train attack model (on extended features)
    # ------------------------------------------------------------------
    def _train_attack_model(self):
        conf_cols = [f"class_{c}" for c in range(self.num_classes)]
        var_cols = ["variance_of_max"]
        feature_cols = conf_cols + var_cols

        X = self.attack_dataset[feature_cols].values
        y = self.attack_dataset["is_part_of_dataset"].values

        self.attack_model = self.attack_model_parameters.build(
            random_state=self.random_state
        )
        self.attack_model.fit(X, y)
        print(
            f"  Attack model trained ({self.attack_model_parameters.model_type}) "
            f"on {X.shape[1]} features."
        )

    # ------------------------------------------------------------------
    # Attack – query victim + compute shadow variance
    # ------------------------------------------------------------------
    def attack(self, data: np.ndarray, return_confidence: bool = False):
        """Predict membership using confidence + variance features.

        Parameters
        ----------
        data : np.ndarray
            Data points to query (same format as unlabelled_data).
        return_confidence : bool
            If True, also return attack model probabilities.

        Returns
        -------
        predictions : np.ndarray of {0, 1}
        confidences : np.ndarray (only if return_confidence=True)
        """
        if not self._is_trained:
            raise RuntimeError("Call .execute() before .attack().")

        # Get victim model confidence scores
        victim_scores = self.victim_model_api.predict(data)
        victim_scores = np.asarray(victim_scores)
        if victim_scores.ndim == 1:
            victim_scores = victim_scores.reshape(1, -1)

        # Get per-class variance across shadow models
        variance, _ = self._compute_cross_model_variance(data)

        # Combine: [confidence_scores, variance_scores]
        features = np.hstack([victim_scores, variance])

        predictions = self.attack_model.predict(features)

        if return_confidence:
            if hasattr(self.attack_model, "predict_proba"):
                proba = self.attack_model.predict_proba(features)
            else:
                proba = self.attack_model.decision_function(features)
            return predictions, proba

        return predictions

    # ------------------------------------------------------------------
    # Evaluate
    # ------------------------------------------------------------------
    def evaluate(
        self,
        member_data: np.ndarray,
        non_member_data: np.ndarray,
    ) -> dict:
        """Evaluate attack on known member / non-member data."""
        if member_data.dtype.kind in ("U", "O") or non_member_data.dtype.kind in ("U", "O"):
            X = np.concatenate([member_data, non_member_data])
        else:
            X = np.vstack([member_data, non_member_data])

        y_true = np.concatenate([
            np.ones(len(member_data)),
            np.zeros(len(non_member_data)),
        ])

        y_pred = self.attack(X)

        return {
            "accuracy": accuracy_score(y_true, y_pred),
            "precision": precision_score(y_true, y_pred, zero_division=0),
            "recall": recall_score(y_true, y_pred, zero_division=0),
            "f1": f1_score(y_true, y_pred, zero_division=0),
        }

    # ------------------------------------------------------------------
    # Repr
    # ------------------------------------------------------------------
    def __repr__(self):
        status = "trained" if self._is_trained else "not trained"
        return (
            f"VarianceMIA(num_classes={self.num_classes}, "
            f"num_shadow_models={self.num_shadow_models}, "
            f"shadow={self.shadow_model_parameters!r}, "
            f"attack={self.attack_model_parameters!r}, "
            f"features=confidence+variance, "
            f"status={status})"
        )
